#include <stdio.h>
#define MAX 100

char* mystrchr(const char* s, char c) {
	__asm {
	push	ebx		; salva o valor de EBX recebido de main()
	mov		ebx, s	; le da pilha o primeiro argumento de chamada (char*)
	mov		cl, c	; le o caracter (char) dentro da DWORD empilhada
compare:
	cmp		cl, byte ptr [ebx]
	je		encontrou
	cmp		byte ptr [ebx], 0	; encontrou o terminador nulo?
	je		fim_string
	inc		ebx				; incrementa EBX (vai para o endereco+1)
	jmp		compare
fim_string:
	xor		eax, eax	; EAX contera o ponteiro NULL como retorno
	jmp		retorno
encontrou:
	mov		eax, ebx	; EAX eh o registrador de retorno, salva nele o endereco
	jmp		retorno
retorno:
	pop		ebx
	}
}

int main(int argc, char* argv[]) {
    char string[MAX], ch; 
    char* end;

    printf("Digite uma string: ");
    scanf(" %s", string);

    printf("Digite um caracter: ");
    scanf(" %c", &ch);

    end = mystrchr(string, ch);

    if (end) {
        printf("O caracter %c estah na %da. posicao da string %s.\n", ch, end-string+1, string);
    }   
    else {
        printf("O caracter %c nao estah presente na string %s.\n", ch, string);
    }   
    return 0;
}
