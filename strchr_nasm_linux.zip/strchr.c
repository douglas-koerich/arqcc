#include <stdio.h>
#define MAX 100

char* mystrchr(const char* s, char c); 

int main(int argc, char* argv[]) {
    char string[MAX], ch; 
    char* end;

    printf("Digite uma string: ");
    scanf(" %s", string);

    printf("Digite um caracter: ");
    scanf(" %c", &ch);

    end = mystrchr(string, ch);

    if (end) {
        printf("O caracter %c estah na %da. posicao da string %s.\n", ch, end-string+1, string);
    }   
    else {
        printf("O caracter %c nao estah presente na string %s.\n", ch, string);
    }   
    return 0;
}

