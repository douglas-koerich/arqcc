// Prototipo da funcao que foi escrita em assembly, mas porque eh
// compilada com C requer este arquivo-cabecalho (ou a linha abaixo
// deveria estar no arquivo-fonte hello.c)
int imprime(char*);

