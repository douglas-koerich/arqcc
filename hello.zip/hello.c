#include <stdio.h>
#include "hello.h"

int main(int argc, char* argv[]) {
	if (argc < 2) {
		puts("Numero invalido de parametros");
		printf("Use: %s <seu-nome>\n", argv[0]);
		return -1;
	}
	int x = imprime(argv[1]);
	printf("O valor retornado pela funcao foi %d.\n", x);
	return 0;
}

